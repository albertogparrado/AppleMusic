//
//  SongCell.swift
//  AppleMusic
//
//  Created by Alberto on 10/6/21.
//

import UIKit

class SongCell: UITableViewCell {
   
    @IBOutlet weak var songImage: UIImageView!
    @IBOutlet weak var songTitle: UILabel!
   
    
    override func awakeFromNib() {
        super.awakeFromNib()
        songTitle.text = "Song"
        songImage.image = UIImage(named: "Queen")
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        selectionStyle = .none
       
    }
    
    
    func setData(song: Song) {
        songTitle.text = song.title
        songImage.image = UIImage(named: song.image)
        
        songImage.layer.cornerRadius = 4
    }
}
