//
//  Song_Cell.swift
//  AppleMusic
//
//  Created by Alberto on 10/6/21.
//

import UIKit

class Song_Cell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
