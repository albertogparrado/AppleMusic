//
//  Song.swift
//  AppleMusic
//
//  Created by Alberto on 11/6/21.
//

import Foundation

struct Song {
    var image: String
    var title: String
}

struct AlbumPortada {
    var image: String
    var title: String
}
