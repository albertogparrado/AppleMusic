//
//  MyMusicTableViewController.swift
//  AppleMusic
//
//  Created by Alberto on 10/6/21.
//

import UIKit

class MyMusicTableViewController: UITableViewController {
    
    var misCells: MCell = MCell(xibName: "SongCell", idReuse: "SongCell")
    var allSong:[Song] = []
    var contador: Int = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let song1 = Song(image: "Queen", title: "Quen")
        let song2 = Song(image: "kizz", title: "Kizz")
        let song3 = Song(image: "Queen", title: "Balvin")
        let song4 = Song(image: "kizz", title: "Cosas")
        
        allSong.append(contentsOf: [song1, song2, song3, song4])

        self.tableView!.register(UINib(nibName: misCells.xibName, bundle: nil), forCellReuseIdentifier: misCells.idReuse)
        self.tableView!.separatorStyle = .none
    }

    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return allSong.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         
        let cell = tableView.dequeueReusableCell(withIdentifier: misCells.idReuse, for: indexPath) as! SongCell
        
       //Añado datos
        let data = allSong[indexPath.row]
        
        cell.setData(song: data)
        
        print(data.title)
          return cell
      }


}

struct MCell {
    var xibName: String
    var idReuse: String
}

struct Album {
    var imageAlbum: String
    var name: String
}

struct SongAlbum {
    var nameSong: String
    var imageSong: String
}
