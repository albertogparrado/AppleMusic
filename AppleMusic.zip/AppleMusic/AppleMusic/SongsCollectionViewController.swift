//
//  SongsCollectionViewController.swift
//  AppleMusic
//
//  Created by Alberto on 11/6/21.
//

import UIKit

class SongsCollectionViewController: UICollectionViewController, UICollectionViewDelegateFlowLayout {
    
    
    
    var misCells: MCell = MCell(xibName: "AlbumCell", idReuse: "AlbumCell")
    
    var allAlbum: [Album] = []
    var Songs: [Song] = []
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Playlist"
        
        //Albumes
        let album1 = Album(imageAlbum: "p0", name: "Finde")
        let album2 = Album(imageAlbum: "p1", name: "Invierno")
        let album3 = Album(imageAlbum: "p2", name: "TOP 50")
        let album4 = Album(imageAlbum: "p3", name: "Reggaeton")
        let album5 = Album(imageAlbum: "p4", name: "Verano")
        let album6 = Album(imageAlbum: "p5", name: "TOP 2018")
        allAlbum.append(contentsOf: [album1, album2, album3, album4, album5, album6])
        
        //Canciones
        let cancion1 = Song(image: "Queen", title: "Quen")
        let cancion2 = Song(image: "Queen", title: "Quen")
        let cancion3 = Song(image: "Queen", title: "Quen")
        let cancion4 = Song(image: "Queen", title: "Quen")
        let cancion5 = Song(image: "Queen", title: "Quen")
        let cancion6 = Song(image: "Queen", title: "Quen")
        let cancion7 = Song(image: "Queen", title: "Quen")
        Songs.append(contentsOf: [cancion1, cancion2, cancion3, cancion4, cancion5, cancion6, cancion7])
        
        

        let layout = UICollectionViewFlowLayout()
                layout.scrollDirection = .vertical
                layout.minimumLineSpacing = 8
                layout.minimumInteritemSpacing = 4
        
        collectionView.setCollectionViewLayout(layout, animated: true)
        
        self.collectionView!.register(UINib(nibName: misCells.xibName, bundle: nil), forCellWithReuseIdentifier: misCells.idReuse)
        
    }
     
    //TAB y te lleva a la pantalla
    var nombrePlaylist: String?
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        nombrePlaylist = allAlbum[indexPath.row].name
        
       
        performSegue(withIdentifier: "SegueTable", sender: self)
        

        print(nombrePlaylist)
        print(indexPath.row)
        
    }
    
    //Pasar info a la otra pantalla
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
       
        if segue.identifier == "SegueTable"{
            
            if let ControlerDestination = segue.destination as? SongsInAlbumTableViewController {
                ControlerDestination.tituloReciv = nombrePlaylist
                ControlerDestination.cancionesShared = Songs
            }
        }
    }
        
    
    
    
    // MARK: UICollectionViewDataSource
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return allAlbum.count
    }
    
    
    //Veces que va procesando cada elemento
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: misCells.idReuse, for: indexPath) as! AlbumCell
        
        let myAlbum = allAlbum[indexPath.row]
        cell.setAlbum(data: myAlbum)
        
        return cell
    }
    
    //espaciado que deja dentro de la vista
    func collectionView(_ collectionView: UICollectionView,
                            layout collectionViewLayout: UICollectionViewLayout,
                            insetForSectionAt section: Int) -> UIEdgeInsets {
            return UIEdgeInsets(top: 16.0, left: 12.0, bottom: 24.0, right: 12.0)
        }
        
    
    //
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
            
            let lay = collectionViewLayout as! UICollectionViewFlowLayout
            let mainSize = collectionView.frame.width / 2 - lay.minimumInteritemSpacing
            return CGSize(width: mainSize - 12, height: mainSize)
            
        }
    
}
