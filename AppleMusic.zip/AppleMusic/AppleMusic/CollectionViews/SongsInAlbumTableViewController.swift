//
//  SongsInAlbumTableViewController.swift
//  AppleMusic
//
//  Created by Alberto on 11/6/21.
//

import UIKit

class SongsInAlbumTableViewController: UITableViewController {
    
    var tituloReciv: String?
    var canciones: [Song] = []
    var cancionesShared: [Song] = []
    


    override func viewDidLoad() {
        super.viewDidLoad()

        title = tituloReciv
        
        let song1 = Song(image: "Queen", title: "Quen")
        let song2 = Song(image: "kizz", title: "Kizz")
        let song3 = Song(image: "Queen", title: "Balvin")
        let song4 = Song(image: "kizz", title: "Cosas")
        
        canciones.append(contentsOf: [song1, song2, song3, song4])
        
        //Se construye las filas según el formato que le damos con el "SongCell"
        self.tableView!.register(UINib(nibName: "SongCell", bundle: nil), forCellReuseIdentifier: "SongCell")
        self.tableView!.separatorStyle = .none
    }

    // MARK: - Table view data source
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return cancionesShared.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "SongCell", for: indexPath) as! SongCell
       
        let data = cancionesShared[indexPath.row]
        cell.setData(song: data)
        
        return cell
    }

   
}

struct CancionesAlbum {
    var image: String
    var title: String
}
