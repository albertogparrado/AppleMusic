//
//  AlbumCell.swift
//  AppleMusic
//
//  Created by Alberto on 11/6/21.
//

import UIKit

class AlbumCell: UICollectionViewCell {
   
    @IBOutlet weak var imageAlbum: UIImageView!
    @IBOutlet weak var nameAlbum: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func setAlbum(data: Album){
//        colorAlbum.backgroundColor = data.colorAlbum
        nameAlbum.text = data.name
        imageAlbum.image = UIImage(named: data.imageAlbum)
        
        
        imageAlbum.layer.cornerRadius = 25
    
    }
    
}
