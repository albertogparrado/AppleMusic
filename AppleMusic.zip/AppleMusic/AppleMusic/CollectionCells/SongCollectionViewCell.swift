//
//  SongCollectionViewCell.swift
//  AppleMusic
//
//  Created by Alberto on 11/6/21.
//

import UIKit

class SongCollectionViewCell: UICollectionViewCell {
    
}
